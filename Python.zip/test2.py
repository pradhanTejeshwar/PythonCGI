#!C:\Users\Amit\AppData\Local\Programs\Python\Python38-32\python.exe
print("Content-type:text/html\r\n\r\n")
print('<!DOCTYPE html><html><head><title>1-Search</title></head><body><h1>Hi</h1></body></html>')
